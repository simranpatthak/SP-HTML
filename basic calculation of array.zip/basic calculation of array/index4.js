const array = [17, 42, 8, 35, 21];
let max = array[0];

for (let i = 1; i < array.length; i++) {
    if (array[i] > max) {
        max = array[i]; 
    }
}

console.log("Maximum element in the array:", max);