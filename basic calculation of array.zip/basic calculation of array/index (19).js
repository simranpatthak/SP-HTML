let array = [3, 7, 12, 5, 9];
let sum = 0;

for (let i = 0; i < array.length; i++) {
    sum += array[i];
}

console.log("Sum of all elements:", sum);
