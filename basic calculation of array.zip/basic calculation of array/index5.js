// Question Determine the minimum element in the array: [9, 14, 3, 27, 6].
// Task5
const array = [9, 14, 3, 27, 6];
let min = array[0];

for (let i = 1; i < array.length; i++) {
    if (array[i] < min) {
        min = array[i];
    }
}

console.log("Minimum element in the array:", min);