const array = [2, 4, 6, 8, 10];
let sum = 0;

for (let i = 0; i < array.length; i++) {
    sum += array[i];
}

const average = sum / array.length;

console.log("Average of all elements:", average);