// task 1 of inheritence
class Animal {
    constructor(name) {
        this.name = name;
    }
    speak() {
        console.log(`${this.name} makes a noise.`);
    }
}

class Dog extends Animal {
    speak() {
        console.log(`${this.name} barks.`);
    }
}

let dog = new Dog('Buddy');
dog.speak();

// The above code we can clearly see that thier are two class where second class has all the excess of first class that is (Animal class) using  extends key word.
// 2.Now when user run the code he/she will get [Out = Buddy barks]
// You must be thinking how .
// when you will call the function in the place of name thier will be buddy + barks=buddy barks
//let dog is variable where we have store the value 
// new dog ('buddy') is the value/agrument
// this.name=[Buddy] adding bark.
// it is behaving like polimorfisome. 



// task 2


class Shape {
    constructor(color) {
        this.color = color;
    }
    getColor() {
        return this.color;
    }
}

class Circle extends Shape {
    constructor(color, radius) {
        super(color);
        this.radius = radius;
    }
}

class ColoredCircle extends Circle {
    constructor(color, radius) {
        super(color, radius);
    }
}

let coloredCircle = new ColoredCircle('blue', 5);
console.log(coloredCircle.getColor());

// from the above code we can understand that  There's a base class Shape with a constructor to set the color and a method getColor() to . Then there's a subclass Circle inheriting from Shape, which adds a radius property. Lastly, there's a subclass ColoredCircle inheriting from Circle.

// In the end ColoredCircle is created with a blue color and a radius of 5. It then prints out the color of the circle using the getColor() method.

javascriptCopy code
class Vehicle {
    constructor(make, model) {
        this.make = make;
        this.model = model;
    }
    getInfo() {
        return `Make: ${this.make}, Model: ${this.model}`;
    }
}

class Car extends Vehicle {
    constructor(make, model, year) {
        super(make, model);
        this.year = year;
    }
    getInfo() {
        return `${super.getInfo()}, Year: ${this.year}`;
    }
}

let myCar = new Car('Toyota', 'Camry', 2020);
console.log(myCar.getInfo());

// The Vehicle class has a constructor to set make and model, and a method getInfo() to retrieve this information.

// The Car class extends Vehicle and adds a year property. It overrides the getInfo() method to include the year along with make and model.